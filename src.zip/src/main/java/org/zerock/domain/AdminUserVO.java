package org.zerock.domain;

import java.util.Date;

import lombok.Data;
@Data
public class AdminUserVO {
    private String adminId;
    private String adminPw;
    private String adminName;
    private Date regDate;
}