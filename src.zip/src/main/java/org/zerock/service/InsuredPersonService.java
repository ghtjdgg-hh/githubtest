package org.zerock.service;

import java.util.List;

import org.zerock.domain.InsuredPersonVO;

public interface InsuredPersonService {

    // 전체 피보험자 목록 조회
    List<InsuredPersonVO> getList();

    // 특정 피보험자 단건 조회
    InsuredPersonVO get(String insured_id);

    // 피보험자 등록
    void register(InsuredPersonVO vo);

    // 피보험자 정보 수정
    boolean modify(InsuredPersonVO vo);

    // 피보험자 삭제
    boolean remove(String insured_id);

    // 🔹 특정 고객 ID로 피보험자 목록 조회 (Ajax or 연동용)
    List<InsuredPersonVO> getByCustomerId(String customerId);
}
